// RescFlow checkpoint implementation. Compilation/execution not verified in the authoring environment.
// This is a site inventory and SSA value-origin analysis, NOT an ownership proof.
package main

import (
 "encoding/json"
 "flag"
 "fmt"
 "go/token"
 "os"
 "path/filepath"
 "sort"
 "strings"

 "golang.org/x/tools/go/packages"
 "golang.org/x/tools/go/ssa"
 "golang.org/x/tools/go/ssa/ssautil"
)

type Site struct {
 Kind string `json:"kind"`
 Function string `json:"function"`
 File string `json:"file"`
 Line int `json:"line"`
 Column int `json:"column"`
 Block int `json:"block"`
 Text string `json:"text"`
 Origins []string `json:"origins"`
 Status string `json:"status"`
}
type Report struct {
 Schema string `json:"schema"`
 Scope string `json:"scope"`
 BenchmarkSummaries bool `json:"benchmark_summaries"`
 Sites []Site `json:"sites"`
}
type origin struct { ids map[string]bool; complete bool }
var fset *token.FileSet
var summaries bool
func position(p token.Pos) (string,int,int) {
 q:=fset.Position(p); name:=filepath.ToSlash(q.Filename)
 if cwd,e:=os.Getwd();e==nil {if r,e:=filepath.Rel(cwd,q.Filename);e==nil {name=filepath.ToSlash(r)}}
 return name,q.Line,q.Column
}
func resourceCall(c *ssa.CallCommon) bool {
 f:=c.StaticCallee();if f==nil || f.Pkg==nil{return false}
 if f.Pkg.Pkg.Path()!="os" {return false}
 switch f.Name(){case "Open","OpenFile","Create","CreateTemp":return true};return false
}
func summaryCall(c *ssa.CallCommon,name string) bool {
 f:=c.StaticCallee()
 return summaries && f!=nil && f.Pkg!=nil && f.Name()==name && strings.HasPrefix(f.Pkg.Pkg.Path(),"example.com/rescflow/benchmarks/")
}
func resourceID(c *ssa.Call) string {p,l,_:=position(c.Pos());return fmt.Sprintf("%s:%d",p,l)}
func origins(v ssa.Value, seen map[ssa.Value]bool) origin {
 o:=origin{map[string]bool{},true}
 if v==nil {o.complete=false;return o};if seen[v] {o.complete=false;return o}
 seen[v]=true;defer delete(seen,v)
 switch x:=v.(type) {
 case *ssa.Extract:
  if x.Index==0 {if c,ok:=x.Tuple.(*ssa.Call);ok && resourceCall(c.Common()){o.ids[resourceID(c)]=true;return o}}
 case *ssa.ChangeType: return origins(x.X,seen)
 case *ssa.Convert: return origins(x.X,seen)
 case *ssa.ChangeInterface: return origins(x.X,seen)
 case *ssa.MakeInterface: return origins(x.X,seen)
 case *ssa.Phi:
  for _,e:=range x.Edges {z:=origins(e,seen);for id:=range z.ids{o.ids[id]=true};o.complete=o.complete&&z.complete};return o
 case *ssa.Const: if x.IsNil(){return o}
 }
 // Loads, heap fields, closure cells, parameters, and arbitrary call returns need summaries.
 o.complete=false;return o
}
func keys(o origin) []string {r:=[]string{};for id:=range o.ids{r=append(r,id)};sort.Strings(r);return r}
func cleanupArg(c *ssa.CallCommon) (ssa.Value,bool) {
 if summaryCall(c,"closeFile") && len(c.Args)==2{return c.Args[1],true}
 f:=c.StaticCallee()
 if f!=nil && f.Pkg!=nil && f.Pkg.Pkg.Path()=="os" && f.Name()=="Close" && len(c.Args)>0{return c.Args[0],true}
 // An invoked Close need not close an os.File. Report unresolved, do not invent an association.
 return nil,false
}
func main(){
 flag.BoolVar(&summaries,"benchmark-summaries",false,"enable exact benchmark helper summaries")
 dump:=flag.String("ssa-dir","","optional SSA text dump directory")
 flag.Parse();patterns:=flag.Args();if len(patterns)==0{patterns=[]string{"./benchmarks/..."}}
 cfg:=&packages.Config{Mode:packages.LoadAllSyntax}
 pkgs,err:=packages.Load(cfg,patterns...);if err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(1)}
 if packages.PrintErrors(pkgs)>0{os.Exit(1)}
 prog,initial:=ssautil.AllPackages(pkgs,ssa.SanityCheckFunctions);prog.Build();fset=prog.Fset
 report:=Report{"rescflow-v0.1","intraprocedural value origins; no path-sensitive lifetime proof",summaries,[]Site{}}
 var funcs []*ssa.Function
 var collect func(*ssa.Function)
 collect=func(f *ssa.Function){funcs=append(funcs,f);for _,a:=range f.AnonFuncs{collect(a)}}
 for _,p:=range initial {if p==nil{continue};for _,m:=range p.Members{if f,ok:=m.(*ssa.Function);ok{collect(f)}}}
 sort.Slice(funcs,func(i,j int)bool{return funcs[i].String()<funcs[j].String()})
 if *dump!="" {if err:=os.MkdirAll(*dump,0755);err!=nil{panic(err)}}
 for n,f:=range funcs {
  if *dump!="" {p:=filepath.Join(*dump,fmt.Sprintf("%04d.ssa.txt",n));out,e:=os.Create(p);if e!=nil{panic(e)};f.WriteTo(out);out.Close()}
  for _,b:=range f.Blocks {for _,ins:=range b.Instrs {
   file,line,col:=position(ins.Pos())
   s:=Site{Function:f.String(),File:file,Line:line,Column:col,Block:b.Index,Text:ins.String(),Origins:[]string{}}
   switch x:=ins.(type) {
   case *ssa.Call:
    if resourceCall(x.Common()){s.Kind="acquire";s.Origins=[]string{resourceID(x)};s.Status="potential acquisition; success branch not proved"
    }else if v,ok:=cleanupArg(x.Common());ok {s.Kind="explicit_cleanup";o:=origins(v,map[ssa.Value]bool{});s.Origins=keys(o);s.Status=fmt.Sprintf("value_origins_complete=%t",o.complete)
    }else {continue}
   case *ssa.Defer:
    s.Kind="defer";s.Status="unresolved: closure, interface, or unsupported cleanup"
    if v,ok:=cleanupArg(x.Common());ok{o:=origins(v,map[ssa.Value]bool{});s.Origins=keys(o);s.Status=fmt.Sprintf("value_origins_complete=%t; execution path/order not proved",o.complete)}
   case *ssa.RunDefers:s.Kind="run_defers";s.Status="function-frame cleanup point; not a lexical block exit"
   case *ssa.Return:
    s.Kind="return";s.Status="return values may transfer handles; not proof of open state"
    for _,v:=range x.Results{o:=origins(v,map[ssa.Value]bool{});s.Origins=append(s.Origins,keys(o)...)}
   case *ssa.Store:
    o:=origins(x.Val,map[ssa.Value]bool{});if len(o.ids)==0{continue}
    s.Kind="store";s.Origins=keys(o);s.Status="storage observed; escape/lifetime unresolved"
   default:continue
   }
   report.Sites=append(report.Sites,s)
  }}
 }
 sort.SliceStable(report.Sites,func(i,j int)bool{a,b:=report.Sites[i],report.Sites[j];if a.File!=b.File{return a.File<b.File};if a.Line!=b.Line{return a.Line<b.Line};return a.Kind<b.Kind})
 enc:=json.NewEncoder(os.Stdout);enc.SetIndent("","  ");if err:=enc.Encode(report);err!=nil{panic(err)}
}
