#!/usr/bin/env python3
"""Honest baseline preflight + translation/build attempts. Adapters require local verification.
Go2Rust stdout mode is attempted with rustc; dependency-related build errors are adapter
integration errors until rerun with the upstream supported project build configuration.
Rustygo's build combines translation and compilation; its failures are not classified as
translation-only failures. Never label a missing tool as a translator failure.
"""
import argparse,json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(cmd,cwd,timeout=180):
 try:
  p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
  return dict(command=list(map(str,cmd)),returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
 except (OSError,subprocess.TimeoutExpired) as e:return dict(command=list(map(str,cmd)),error=str(e))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--go2rust');ap.add_argument('--rustygo');args=ap.parse_args()
 rows=[];labels=json.loads((ROOT/'benchmarks/labels.json').read_text())
 original=json.loads((ROOT/'results/go_runs.json').read_text()) if (ROOT/'results/go_runs.json').exists() else {'programs':[]}
 observed={x['id']:x for x in original['programs']}
 out=ROOT/'results/baseline_artifacts';out.mkdir(exist_ok=True)
 for name in ['go2rust','rustygo']:
  exe=getattr(args,name) or shutil.which(name)
  required=['go','rustc']+(['cargo'] if name=='rustygo' else [])
  missing=[x for x in required if not shutil.which(x)]
  if not exe or not Path(exe).is_file():missing.append(name)
  for c in labels:
   row=dict(tool=name,id=c['id'],runs=[])
   if missing:row.update(status='blocked_environment',missing=missing);rows.append(row);continue
   work=out/(name+'_'+c['id']);work.mkdir(exist_ok=True);binary=work/'program'
   if name=='go2rust':
    trans=run([str(Path(exe).resolve()),str(ROOT/c['file'])],work);row['translation']=trans
    if trans.get('returncode')!=0:row['status']='translation_command_failed';rows.append(row);continue
    rs=work/'output.rs';rs.write_text(trans['stdout'])
    build=run(['rustc','--edition=2021',str(rs),'-o',str(binary)],work)
    row['build']=build
    if build.get('returncode')!=0:
     row['status']='single_file_build_failed_needs_upstream_adapter_check';rows.append(row);continue
   else:
    emit=run([str(Path(exe).resolve()),'emit','-o',str(work/'emitted'),'.'],(ROOT/c['file']).parent)
    row['translation']=emit
    if emit.get('returncode')!=0:row['status']='emit_command_failed';rows.append(row);continue
    build=run([str(Path(exe).resolve()),'build','-o',str(binary),'.'],(ROOT/c['file']).parent)
    row['combined_build']=build
    if build.get('returncode')!=0:row['status']='combined_build_failed';rows.append(row);continue
   with tempfile.TemporaryDirectory(prefix='rescflow-baseline-') as t:
    inp=Path(t)/'input.txt';inp.write_text('resource fixture\n')
    for spec in c['inputs']:
     r=run([str(binary),str(inp),spec['mode']],t,30);r['mode']=spec['mode']
     original_runs=observed.get(c['id'],{}).get('runs',[])
     ref=next((x for x in original_runs if x['mode']==spec['mode']),None)
     r['matches_observed_go']=None if ref is None else all(r.get(k)==ref.get(k) for k in ['stdout','stderr','returncode'])
     row['runs'].append(r)
   row['status']='executed';rows.append(row)
 result=dict(adapter_status='compiler-dependent paths unverified at authoring time',rows=rows)
 (ROOT/'results/baselines.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({name:{'rows':20,'blocked':sum(r['tool']==name and r['status']=='blocked_environment' for r in rows),'executed':sum(r['tool']==name and r['status']=='executed' for r in rows)} for name in ['go2rust','rustygo']},indent=2))
 return 0 if all(r['status']=='executed' for r in rows) else 2
if __name__=='__main__':sys.exit(main())
