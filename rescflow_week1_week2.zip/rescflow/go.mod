module example.com/rescflow

go 1.27.0

require golang.org/x/tools v0.52.0
